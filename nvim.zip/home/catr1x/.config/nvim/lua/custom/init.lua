-- Ensure pyright starts for Python files
vim.api.nvim_create_autocmd({"BufRead", "BufNewFile"}, {
  pattern = "*.py",
  callback = function()
    vim.defer_fn(function()
      local clients = vim.lsp.get_active_clients({ name = "pyright" })
      if #clients == 0 then
        vim.cmd("LspStart pyright")
      end
    end, 100)
  end,
})
