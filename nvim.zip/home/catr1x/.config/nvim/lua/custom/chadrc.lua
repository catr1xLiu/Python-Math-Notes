local M = {}

M.ui = {
  theme = "onedark",
  
  -- Enable icons
  icons = {
    enable = true,
  },
}

M.plugins = "custom.plugins"

return M
