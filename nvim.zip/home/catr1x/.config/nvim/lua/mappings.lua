require "nvchad.mappings"

-- add yours here

local map = vim.keymap.set

map("n", ";", ":", { desc = "CMD enter command mode" })
map("i", "jk", "<ESC>")

-- map({ "n", "i", "v" }, "<C-s>", "<cmd> w <cr>")

local M = {}

M.dap = {
  plugin = true,
  n = {
    ["<leader>db"] = { "<cmd> DapToggleBreakpoint <CR>", "Toggle breakpoint" },
    ["<leader>dr"] = { "<cmd> DapContinue <CR>", "Start/Continue debugging" },
    ["<leader>ds"] = { "<cmd> DapStepOver <CR>", "Step over" },
    ["<leader>di"] = { "<cmd> DapStepInto <CR>", "Step into" },
    ["<leader>do"] = { "<cmd> DapStepOut <CR>", "Step out" },
    ["<leader>dt"] = { "<cmd> DapTerminate <CR>", "Terminate debugging" },
    ["<leader>du"] = { 
      function()
        local widgets = require("dap.ui.widgets")
        local sidebar = widgets.sidebar(widgets.scopes)
        sidebar.open()
      end,
      "Open debug sidebar"
    },
  }
}

return M
