require("nvchad.configs.lspconfig").defaults()

-- Python LSP 
require'lspconfig'.pyright.setup{}

-- C++ LSP
require'lspconfig'.clangd.setup{}

local servers = { "html", "cssls" }
vim.lsp.enable(servers)

-- read :h vim.lsp.config for changing options of lsp servers
